# Gondwana Prime — Native Android v2

Updated Kotlin / Jetpack Compose app **and a separate authenticated Python backend**.
No WebView. This source ZIP does not deploy or update an already-installed app.

Start with **START_SMALL.md** for the selected small pilot setup. `render.yaml` defines one small paid Render instance and a 1 GB persistent disk, with payments OFF. Use **SETUP.md** for full provider configuration, then build and install an APK. No cloud resource has been deployed by this ZIP.

## Implemented

- Credential Manager Google sign-in → server ID-token verification → revocable, encrypted device session.
- Searchable real catalog, movies, series/episode metadata, active event tab and coming-soon state.
- Media3 player, player replacement, lifecycle pause/release, reconnect retry, buffering/error UI.
- My List, Continue Watching, saved watch progress and membership/payment history.
- Private R2/S3 MP4 upload from Android; upload completion checks; create/edit/soft-delete videos.
- Server-enforced roles: viewer, uploader, event_manager, creator, admin.
- Manually named events, one active event, candidate management, performance links, voting toggle.
- One vote per Google account per event, database-enforced; vote totals restricted to Admin/event manager.
- Direct-distribution Razorpay Payment Links for Rent/Buy and 30/365-day prepaid memberships.
- Signed webhook checks, server pricing, duplicate webhook protection, verified entitlement grants.
- Refund webhook revokes that order's entitlement and removes it from sales reports.
- Device management and heartbeat-based simultaneous playback checks.
- Viewing totals and last-position reports, creator revenue share ledger for individual Rent/Buy sales.
- Gradle Wrapper, direct/play build flavors, GitHub build workflow, backend Dockerfile and tests.

## Deliberate deployment boundaries

- No backend credentials or merchant secrets in Android. No fake successful login/payment/upload.
- Existing old website `/api/entries` is not this backend. No old data is migrated automatically.
- `direct` APK has external checkout; `play` build is consumption-only with checkout hidden. Google Play Billing and alternative-billing enrollment are **not** implemented.
- Memberships require manual renewal; recurring mandates and automatic creator bank payouts are not implemented.
- MP4 upload is a foreground single PUT (up to 5 GB), not resumable/background multipart upload. Keep the app open.
- Adaptive renditions/transcoding, DRM and live broadcast ingest are not implemented. Data Saver selects a lower available track; a single MP4 has no alternate bitrate and will not become smaller.
- Signed media links expire in 4 hours. This provides access control, not DRM or a hard guarantee against URL sharing. Device/screen checks cover API-issued sessions; shared signed URLs bypass heartbeat control.
- Revenue allocation applies to gross individual video sales using a snapshot of the configured percentage. Membership revenue pooling, tax/provider-fee accounting and payouts require separate business rules.
- Reference backend is one persistent SQLite instance. It is not sized or load-tested for 100,000 viewers.

See VALIDATION.md for exact checks performed and remaining device/provider checks.
