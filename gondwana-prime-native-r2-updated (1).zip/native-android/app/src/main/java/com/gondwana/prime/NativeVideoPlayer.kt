package com.gondwana.prime

import android.net.ConnectivityManager
import android.net.Network
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

@Composable
fun NativeVideoPlayer(url: String, start: Long, saver: Boolean, onProgress: (Long, Long, Int, Boolean) -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val report by rememberUpdatedState(onProgress)
    var buffering by remember(url) { mutableStateOf(true) }
    var error by remember(url) { mutableStateOf<String?>(null) }
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url)); seekTo(start); prepare(); playWhenReady = true
        }
    }
    LaunchedEffect(player, saver) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setMaxVideoBitrate(if (saver) 700_000 else Int.MAX_VALUE)
            .setMaxVideoSize(if (saver) 854 else Int.MAX_VALUE, if (saver) 480 else Int.MAX_VALUE).build()
    }
    LaunchedEffect(player, owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
        while (true) {
            var seconds = 0
            repeat(15) { delay(1000); if (player.isPlaying) seconds++ }
            report(player.currentPosition.coerceAtLeast(0), player.duration.coerceAtLeast(0), seconds, false)
        }
    }
    }
    DisposableEffect(player, owner) {
        var disposed = false
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onPlayerError(e: PlaybackException) { error = "वीडियो नहीं चल पाया। Connection जाँचें और फिर प्रयास करें।" }
        }
        val lifecycle = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                player.pause()
                report(player.currentPosition.coerceAtLeast(0), player.duration.coerceAtLeast(0), 0, true)
            }
        }
        val connectivity = context.getSystemService(ConnectivityManager::class.java)
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    if (!disposed && player.playerError != null) { error = null; player.prepare() }
                }
            }
        }
        player.addListener(listener); owner.lifecycle.addObserver(lifecycle)
        connectivity.registerDefaultNetworkCallback(callback)
        onDispose {
            disposed = true
            report(player.currentPosition.coerceAtLeast(0), player.duration.coerceAtLeast(0), 0, true)
            connectivity.unregisterNetworkCallback(callback)
            owner.lifecycle.removeObserver(lifecycle); player.removeListener(listener); player.release()
        }
    }
    Column {
        AndroidView(factory = { PlayerView(it).apply { useController = true } }, update = { it.player = player }, modifier = Modifier.fillMaxWidth().height(240.dp))
        if (buffering) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Buffering… इंटरनेट की प्रतीक्षा") }
        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
            Button(onClick = { error = null; player.prepare(); player.play() }) { Text("फिर चलाएँ") }
        }
        if (saver) Text("Data Saver ON • उपलब्ध कम bitrate track चुना जाएगा", style = MaterialTheme.typography.bodySmall)
    }
}
