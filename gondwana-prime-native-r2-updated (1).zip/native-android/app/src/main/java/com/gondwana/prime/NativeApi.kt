package com.gondwana.prime

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

class ApiException(val status: Int, message: String) : Exception(message)
fun JSONObject.items(key: String): List<JSONObject> {
    val a = optJSONArray(key) ?: JSONArray()
    return (0 until a.length()).mapNotNull { a.optJSONObject(it) }
}
fun json(vararg values: Pair<String, Any?>) = JSONObject().apply { values.forEach { put(it.first, it.second ?: JSONObject.NULL) } }
fun money(paise: Int) = "₹%.2f".format(paise / 100.0)

object NativeApi {
    var token: String = ""
    private val base get() = BuildConfig.API_BASE_URL.trimEnd('/')
    suspend fun call(path: String, method: String = "GET", body: JSONObject? = null): JSONObject = withContext(Dispatchers.IO) {
        if (base.isBlank()) throw ApiException(503, "Backend URL अभी configure नहीं है। SETUP.md देखें।")
        val connection = URL("$base/api/native$path").openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15000; connection.readTimeout = 35000
            connection.requestMethod = method
            connection.setRequestProperty("Accept", "application/json")
            if (token.isNotBlank()) connection.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = connection.responseCode
            val raw = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            val result = runCatching { JSONObject(raw) }.getOrElse { throw ApiException(code, "Server से सही JSON response नहीं मिला") }
            if (code !in 200..299) throw ApiException(code, result.optString("detail", "Server error $code"))
            result
        } finally { connection.disconnect() }
    }

    suspend fun upload(context: Context, uri: Uri, onProgress: (Int) -> Unit): String = withContext(Dispatchers.IO) {
        val size = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
        } ?: -1L
        require(size in 1..5_000_000_000L) { "MP4 का size 5 GB से कम और ज्ञात होना चाहिए" }
        val ticket = call("/admin/uploads", "POST", json("size" to size, "mime" to "video/mp4"))
        val connection = URL(ticket.getString("url")).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "PUT"; connection.doOutput = true
            connection.connectTimeout = 20000; connection.readTimeout = 120000
            connection.setRequestProperty("Content-Type", "video/mp4")
            connection.setFixedLengthStreamingMode(size)
            val input = context.contentResolver.openInputStream(uri) ?: error("File नहीं खुली")
            input.use { source -> connection.outputStream.use { out ->
                val buffer = ByteArray(128 * 1024); var total = 0L; var lastPercent = -1
                while (true) {
                    val count = source.read(buffer); if (count == -1) break
                    out.write(buffer, 0, count); total += count
                    val percent = (total * 100 / size).toInt()
                    if (percent != lastPercent) { lastPercent = percent; onProgress(percent) }
                }
            } }
            check(connection.responseCode in 200..299) { "Upload failed (${connection.responseCode}); फिर प्रयास करें" }
        } finally { connection.disconnect() }
        call("/admin/uploads/complete", "POST", json("key" to ticket.getString("key")))
        ticket.getString("key")
    }
}
