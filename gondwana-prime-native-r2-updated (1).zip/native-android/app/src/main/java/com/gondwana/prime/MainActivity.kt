package com.gondwana.prime

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.ClearCredentialStateRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PrimeApp() }
    }
}

@Composable private fun PrimeApp() {
    val context = LocalContext.current
    val store = remember { SessionStore(context) }
    val scope = rememberCoroutineScope()
    val credentials = remember { CredentialManager.create(context) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var catalog by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var account by remember { mutableStateOf<JSONObject?>(null) }
    var eventData by remember { mutableStateOf(JSONObject()) }
    var config by remember { mutableStateOf(JSONObject()) }
    var selected by remember { mutableStateOf<JSONObject?>(null) }
    var playback by remember { mutableStateOf<JSONObject?>(null) }
    var dataSaver by remember { mutableStateOf(store.dataSaver) }
    var query by rememberSaveable { mutableStateOf("") }
    var kind by rememberSaveable { mutableStateOf("all") }
    var refresh by remember { mutableIntStateOf(0) }
    fun runAction(action: suspend () -> Unit) {
        if (busy) return
        scope.launch {
            busy = true; message = null
            try { action() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                message = e.message ?: "फिर प्रयास करें"
                if (e is ApiException && e.status == 401) { store.clear(); NativeApi.token = ""; account = null; playback = null }
            } finally { busy = false }
        }
    }
    fun openEntry(e: JSONObject) { selected = e; playback = null }
    fun purchase(mode: String, eid: String = "") = runAction {
        val order = NativeApi.call("/checkout", "POST", json("kind" to mode, "entry_id" to eid))
        val uri = Uri.parse(order.getString("url"))
        check(uri.scheme == "https") { "Invalid payment link" }
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        message = "Payment के बाद Account → Refresh दबाएँ। Server पुष्टि के बाद access मिलेगा।"
    }
    LaunchedEffect(refresh) {
        NativeApi.token = store.load()
        busy = true
        try {
            config = NativeApi.call("/config")
            catalog = NativeApi.call("/entries").items("entries")
            eventData = NativeApi.call("/event")
            account = if (NativeApi.token.isNotBlank()) NativeApi.call("/me") else null
            message = null
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) {
            message = e.message
            if (e is ApiException && e.status == 401) { store.clear(); NativeApi.token = ""; account = null }
        } finally { busy = false }
    }
    val user = account?.optJSONObject("user")
    val role = user?.optString("role") ?: "viewer"
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFEBC36E), background = Color(0xFF0D0B12), surface = Color(0xFF211929))) {
        Scaffold(bottomBar = {
            NavigationBar {
                listOf("होम", "फिल्में", eventData.optJSONObject("event")?.optString("name") ?: "इवेंट", "खाता").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i; selected = null; playback = null }, icon = { Text(listOf("⌂", "▶", "★", "●")[i]) }, label = { Text(label, maxLines = 1) })
                }
            }
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("GONDWANA PRIME", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    TextButton(enabled = !busy, onClick = { refresh++ }) { Text("Refresh") }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                message?.let { Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(12.dp)) }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (selected != null) {
                        val e = selected!!
                        TextButton(onClick = { selected = null; playback = null }) { Text("← वापस") }
                        Text(e.optString("title"), style = MaterialTheme.typography.headlineSmall)
                        Text(e.optString("description"))
                        playback?.let { p ->
                            key(p.getString("play_id")) {
                                NativeVideoPlayer(p.getString("url"), p.optLong("position"), dataSaver) { position, duration, seconds, stop ->
                                    scope.launch {
                                        try { NativeApi.call("/progress/${e.getString("id")}", "POST", json("play_id" to p.getString("play_id"), "position" to position, "duration" to duration, "watched" to seconds, "stop" to stop)) }
                                        catch (ex: CancellationException) { throw ex }
                                        catch (ex: Exception) {
                                            message = "Watch progress save नहीं हुआ: ${ex.message}"
                                            if (ex is ApiException && ex.status in listOf(401, 402, 409)) playback = null
                                        }
                                    }
                                }
                            }
                        }
                        Button(enabled = !busy, onClick = { runAction { playback = NativeApi.call("/entries/${e.getString("id")}/play", "POST") } }) { Text("▶ चलाएँ / Resume") }
                        val saved = account?.items("saved")?.any { it.optString("id") == e.optString("id") } == true
                        OutlinedButton(enabled = !busy, onClick = { runAction {
                            NativeApi.call("/list/${e.getString("id")}", if (saved) "DELETE" else "PUT"); account = NativeApi.call("/me")
                        } }) { Text(if (saved) "My List से हटाएँ" else "+ My List") }
                        if (config.optBoolean("payments_enabled") && BuildConfig.EXTERNAL_PAYMENTS && e.optInt("free") == 0) {
                            if (e.optInt("rent") > 0) Button(enabled = !busy, onClick = { purchase("rent", e.getString("id")) }) { Text("48 घंटे Rent · ${money(e.getInt("rent"))}") }
                            if (e.optInt("buy") > 0) Button(enabled = !busy, onClick = { purchase("buy", e.getString("id")) }) { Text("Buy · ${money(e.getInt("buy"))}") }
                        }
                    } else when (tab) {
                        0, 1 -> {
                            if (tab == 0) Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) {
                                Text("GONDWANA ORIGINAL", color = MaterialTheme.colorScheme.primary)
                                Text("जंगल सत्याग्रह (1930)", style = MaterialTheme.typography.headlineSmall)
                                Text("The Untold History")
                                val film = catalog.firstOrNull { it.optString("title").contains("सत्याग्रह") }
                                if (film != null) Button(onClick = { openEntry(film) }) { Text("अभी देखें") }
                                else Text("Coming soon • उपलब्ध होने पर यहाँ देखें")
                            } }
                            Text(if (tab == 0) "लेटेस्ट वीडियो" else "फिल्में और वेब सीरीज़", style = MaterialTheme.typography.headlineSmall)
                            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("नाम से खोजें") }, modifier = Modifier.fillMaxWidth())
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("all" to "सभी", "movie" to "फिल्में", "series" to "वेब सीरीज़", "event" to "इवेंट").forEach { (id, label) ->
                                    FilterChip(selected = kind == id, onClick = { kind = id }, label = { Text(label, maxLines = 1) })
                                }
                            }
                            if (tab == 0 && query.isBlank()) account?.items("continue")?.takeIf { it.isNotEmpty() }?.let { watching ->
                                Text("Continue Watching", fontWeight = FontWeight.Bold)
                                watching.forEach { p ->
                                    TextButton(onClick = { catalog.firstOrNull { it.optString("id") == p.optString("id") }?.let { openEntry(it) } }) { Text("▶ ${p.optString("title")} · ${p.optLong("position") / 60000} मिनट") }
                                }
                            }
                            val filtered = catalog.filter { (kind == "all" || it.optString("type") == kind) && it.optString("title").contains(query, true) }
                            if (filtered.isEmpty() && !busy) Text("अभी कोई वीडियो उपलब्ध नहीं")
                            filtered.chunked(2).forEach { pair -> Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                pair.forEach { e -> Card(Modifier.weight(1f).clickable { openEntry(e) }) { Column(Modifier.padding(14.dp)) {
                                    Text("▶", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
                                    Text(e.optString("title"), fontWeight = FontWeight.Bold)
                                    Text(if (e.optString("series").isNotBlank()) "${e.optString("series")} · Ep ${e.optInt("episode")}" else e.optString("type"))
                                    Text(if (e.optInt("free") == 1) "Free" else "Rent / Buy / Membership", style = MaterialTheme.typography.bodySmall)
                                } } }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            } }
                        }
                        2 -> {
                            val event = eventData.optJSONObject("event")
                            if (event == null) Text("अभी कोई active event नहीं • Coming soon") else {
                                Text(event.optString("name"), style = MaterialTheme.typography.headlineSmall)
                                Text(event.optString("kind"))
                                if (event.optInt("voting") == 1) Text("एक खाते से इस इवेंट में एक vote")
                                eventData.items("candidates").forEachIndexed { i, c -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                                    Text("${i + 1}. ${c.optString("name")}", fontWeight = FontWeight.Bold)
                                    catalog.firstOrNull { it.optString("id") == c.optString("entry_id") }?.let { e -> TextButton(onClick = { openEntry(e) }) { Text("Performance देखें") } }
                                    if (event.optInt("voting") == 1) Button(enabled = !busy, onClick = { runAction {
                                        NativeApi.call("/events/${event.getString("id")}/vote", "POST", json("candidate_id" to c.getString("id"))); message = "आपका vote दर्ज हो गया"
                                    } }) { Text("Vote करें") }
                                } } }
                            }
                        }
                        else -> {
                            Text("मेरा खाता", style = MaterialTheme.typography.headlineSmall)
                            if (user == null) Button(enabled = !busy, onClick = { runAction {
                                val option = GetSignInWithGoogleOption.Builder(context.getString(R.string.default_web_client_id)).build()
                                val response = credentials.getCredential(context, GetCredentialRequest.Builder().addCredentialOption(option).build())
                                val google = GoogleIdTokenCredential.createFrom(response.credential.data)
                                val result = NativeApi.call("/auth/google", "POST", json("id_token" to google.idToken, "device" to store.device()))
                                NativeApi.token = result.getString("token"); store.save(NativeApi.token)
                                account = NativeApi.call("/me"); message = "Login सफल"
                            } }) { Text("Google से Login") }
                            else {
                                Text(user.optString("name"), fontWeight = FontWeight.Bold); Text(user.optString("email")); Text("Role: $role")
                                OutlinedButton(enabled = !busy, onClick = { runAction {
                                    NativeApi.call("/logout", "POST"); store.clear(); NativeApi.token = ""; account = null; playback = null
                                    credentials.clearCredentialState(ClearCredentialStateRequest())
                                } }) { Text("Logout") }
                                Text("My List", fontWeight = FontWeight.Bold)
                                if (account!!.items("saved").isEmpty()) Text("अभी कोई saved वीडियो नहीं")
                                account!!.items("saved").forEach { e -> TextButton(onClick = { openEntry(e) }) { Text(e.optString("title")) } }
                                Text("Membership / Purchased access", fontWeight = FontWeight.Bold)
                                if (account!!.items("entitlements").isEmpty()) Text("अभी कोई active paid access नहीं")
                                account!!.items("entitlements").forEach { entitlement ->
                                    val name = if (entitlement.optString("entry_id") == "*") "Membership" else catalog.firstOrNull { it.optString("id") == entitlement.optString("entry_id") }?.optString("title") ?: "Purchased video"
                                    Text("$name · ${java.text.DateFormat.getDateInstance().format(java.util.Date(entitlement.optLong("expires") * 1000))} तक")
                                }
                                if (config.optBoolean("payments_enabled") && BuildConfig.EXTERNAL_PAYMENTS) {
                                    Text("Membership • Manual renewal")
                                    listOf("monthly" to "30 दिन", "yearly" to "365 दिन").forEach { (id, label) ->
                                        Button(enabled = !busy, onClick = { purchase(id) }) { Text("$label · ${money(config.optJSONObject("plans")?.optInt(id) ?: 0)}") }
                                    }
                                }
                                Text("Payment History", fontWeight = FontWeight.Bold)
                                account!!.items("orders").forEach { Text("${it.optString("kind")} · ${money(it.optInt("amount"))} · ${it.optString("status")}") }
                                Text("Devices", fontWeight = FontWeight.Bold)
                                account!!.items("devices").forEach { d ->
                                    Text("${d.optString("device").take(8)} ${if (d.optString("device") == store.device()) "(यह device)" else ""}")
                                    if (d.optString("device") != store.device()) TextButton(enabled = !busy, onClick = { runAction {
                                        NativeApi.call("/devices/${d.getString("device")}", "DELETE"); account = NativeApi.call("/me")
                                    } }) { Text("Remove device") }
                                }
                                if (role in listOf("admin", "uploader", "event_manager")) AdminPanel(role, busy, ::runAction) { refresh++ }
                                if (role in listOf("creator", "admin")) {
                                    var revenue by remember { mutableStateOf<JSONObject?>(null) }
                                    Button(enabled = !busy, onClick = { runAction { revenue = NativeApi.call("/creator/revenue") } }) { Text("Creator Revenue") }
                                    revenue?.let { ledger ->
                                        Text("Rent/Buy बिक्री का हिस्सा • Payout अलग से होता है")
                                        if (ledger.items("sales").isEmpty()) Text("अभी कोई बिक्री नहीं")
                                        ledger.items("sales").forEach { sale ->
                                            val title = catalog.firstOrNull { it.optString("id") == sale.optString("entry_id") }?.optString("title") ?: "वीडियो"
                                            Text("$title · ${sale.optString("kind")} · बिक्री ${money(sale.optInt("amount"))} · आपका हिस्सा ${money(sale.optInt("share_paise"))}")
                                        }
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Data Saver"); Switch(checked = dataSaver, onCheckedChange = { dataSaver = it; store.dataSaver = it })
                            }
                            Text("App v${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}
