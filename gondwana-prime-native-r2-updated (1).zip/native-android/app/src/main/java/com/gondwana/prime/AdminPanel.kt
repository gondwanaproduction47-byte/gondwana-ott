package com.gondwana.prime

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID

@Composable private fun Field(label: String, value: String, change: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = change, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
}
@Composable private fun Toggle(label: String, checked: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Switch(checked = checked, onCheckedChange = change) }
}
private fun paise(text: String): Int {
    require(text.toBigDecimalOrNull() != null && text.toBigDecimal() >= java.math.BigDecimal.ZERO) { "सही कीमत लिखें" }
    return text.toBigDecimal().multiply(java.math.BigDecimal(100)).intValueExact()
}

@Composable
fun AdminPanel(role: String, busy: Boolean, run: (suspend () -> Unit) -> Unit, refresh: () -> Unit) {
    val context = LocalContext.current
    var show by remember { mutableStateOf(false) }
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var records by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var title by rememberSaveable { mutableStateOf("") }
    var eid by rememberSaveable { mutableStateOf(UUID.randomUUID().toString()) }
    var type by rememberSaveable { mutableStateOf("movie") }
    var description by rememberSaveable { mutableStateOf("") }
    var objectKey by rememberSaveable { mutableStateOf("") }
    var free by rememberSaveable { mutableStateOf(true) }
    var rent by rememberSaveable { mutableStateOf("0") }
    var buy by rememberSaveable { mutableStateOf("0") }
    var series by rememberSaveable { mutableStateOf("") }
    var episode by rememberSaveable { mutableStateOf("0") }
    var creator by rememberSaveable { mutableStateOf("") }
    var share by rememberSaveable { mutableStateOf("0") }
    var uploadProgress by remember { mutableIntStateOf(-1) }
    var deleteId by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) run {
            uploadProgress = 0
            try {
                objectKey = NativeApi.upload(context, uri) { percent ->
                    android.os.Handler(android.os.Looper.getMainLooper()).post { uploadProgress = percent }
                }
                notice = "Upload पूरा हुआ। अब Save video दबाएँ।"
            } finally { uploadProgress = -1 }
        }
    }
    Button(onClick = { show = !show }) { Text(if (show) "Admin बंद करें" else "Admin Panel") }
    if (!show) return
    if (notice.isNotBlank()) Text(notice)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (role in listOf("admin", "uploader")) TextButton(onClick = { mode = 0 }) { Text("Videos") }
        if (role in listOf("admin", "event_manager")) TextButton(onClick = { mode = 1 }) { Text("Events") }
        if (role in listOf("admin", "event_manager")) TextButton(onClick = { mode = 2 }) { Text("Reports") }
        if (role == "admin") TextButton(onClick = { mode = 3 }) { Text("Team") }
    }
    if (role == "event_manager" && mode == 0) { TextButton(onClick = { mode = 1 }) { Text("Manage events") }; return }
    when (mode) {
        0 -> {
            Button(enabled = !busy, onClick = { run { records = NativeApi.call("/admin/entries").items("entries") } }) { Text("वीडियो सूची Load करें") }
            records.forEach { e ->
                Text("Video ID: ${e.optString("id")}", style = MaterialTheme.typography.bodySmall)
                Row {
                    TextButton(enabled = !busy, onClick = {
                        eid = e.getString("id"); title = e.optString("title"); type = e.optString("type"); description = e.optString("description")
                        objectKey = e.optString("object_key"); free = e.optInt("free") == 1; rent = (e.optInt("rent") / 100.0).toString(); buy = (e.optInt("buy") / 100.0).toString()
                        series = e.optString("series"); episode = e.optInt("episode").toString(); creator = e.optString("creator"); share = e.optInt("share").toString()
                    }) { Text("Edit: ${e.optString("title")}") }
                    if (role == "admin") TextButton(enabled = !busy, onClick = { deleteId = e.getString("id") }) { Text("Delete") }
                }
            }
            TextButton(enabled = !busy, onClick = {
                eid = UUID.randomUUID().toString(); title = ""; description = ""; objectKey = ""; type = "movie"; free = true
                rent = "0"; buy = "0"; series = ""; episode = "0"; creator = ""; share = "0"
            }) { Text("+ नया वीडियो") }
            Field("शीर्षक", title) { title = it }
            Row { listOf("movie", "series", "event").forEach { v -> FilterChip(selected = type == v, onClick = { type = v }, label = { Text(v) }) } }
            Field("विवरण", description) { description = it }
            Button(enabled = !busy, onClick = { picker.launch(arrayOf("video/mp4")) }) { Text("फ़ोन से MP4 Upload") }
            if (uploadProgress >= 0) Text("Uploading: $uploadProgress% • App खुला रखें")
            Text(if (objectKey.isBlank()) "वीडियो upload बाकी है" else "वीडियो attached ✓")
            Toggle("Free video", free) { free = it }
            if (!free) { Field("48 घंटे Rent (₹)", rent) { rent = it }; Field("Buy (₹)", buy) { buy = it } }
            if (type != "movie") { Field("Series / Event collection", series) { series = it }; Field("Episode number", episode) { episode = it } }
            if (role == "admin") { Field("Creator email (optional)", creator) { creator = it }; Field("Creator revenue share %", share) { share = it } }
            Button(enabled = !busy && objectKey.isNotBlank() && title.isNotBlank(), onClick = { run {
                NativeApi.call("/admin/entries/$eid", "PUT", json("title" to title.trim(), "type" to type, "description" to description, "object_key" to objectKey, "free" to free,
                    "rent" to paise(rent), "buy" to paise(buy), "series" to series, "episode" to episode.toInt(), "creator" to creator.trim(), "share" to share.toInt()))
                records = NativeApi.call("/admin/entries").items("entries"); notice = "वीडियो Save हुआ"; refresh()
            } }) { Text("Save video") }
        }
        1 -> EventAdmin(busy, run, refresh)
        2 -> {
            var report by remember { mutableStateOf<JSONObject?>(null) }
            Button(enabled = !busy, onClick = { run { report = NativeApi.call("/admin/report") } }) { Text("Analytics और Votes Load करें") }
            report?.let { r ->
                r.items("analytics").forEach { Text("${it.optString("title")} · ${it.optInt("viewers")} viewers · ${it.optInt("watched_seconds") / 60} minutes watched") }
                r.items("votes").forEach { Text("${it.optString("event")} / ${it.optString("name")}: ${it.optInt("votes")} votes") }
                r.items("revenue").forEach { Text("${it.optString("creator").ifBlank { "Platform / subscriptions" }} · बिक्री ${money(it.optInt("gross_paise"))} · Creator हिस्सा ${money(it.optInt("creator_share_paise"))}") }
                r.items("dropoff").forEach { Text("${it.optString("title")} · last position ${it.optLong("position") / 60000} / ${it.optLong("duration") / 60000} मिनट · ${it.optInt("viewers")} viewers") }
            }
        }
        3 -> {
            var email by rememberSaveable { mutableStateOf("") }
            var teamRole by rememberSaveable { mutableStateOf("uploader") }
            Field("Team member का Google email", email) { email = it }
            Text("सदस्य को पहले एक बार ऐप में login करना होगा")
            listOf("viewer", "uploader", "event_manager", "creator", "admin").forEach { value ->
                FilterChip(selected = teamRole == value, onClick = { teamRole = value }, label = { Text(value) })
            }
            Button(enabled = !busy && email.isNotBlank(), onClick = { run {
                NativeApi.call("/admin/roles", "POST", json("email" to email.trim(), "role" to teamRole)); notice = "Role Save हुआ"
            } }) { Text("Save role") }
        }
    }
    deleteId?.let { id -> AlertDialog(onDismissRequest = { deleteId = null }, title = { Text("वीडियो हटाएँ?") }, text = { Text("यह वीडियो दर्शकों की सूची से हट जाएगा।") },
        confirmButton = { TextButton(enabled = !busy, onClick = { deleteId = null; run {
            NativeApi.call("/admin/entries/$id", "DELETE"); records = NativeApi.call("/admin/entries").items("entries"); refresh()
        } }) { Text("हटाएँ") } }, dismissButton = { TextButton(onClick = { deleteId = null }) { Text("रद्द") } }) }
}

@Composable private fun EventAdmin(busy: Boolean, run: (suspend () -> Unit) -> Unit, refresh: () -> Unit) {
    var records by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var id by rememberSaveable { mutableStateOf(UUID.randomUUID().toString()) }
    var name by rememberSaveable { mutableStateOf("") }
    var kind by rememberSaveable { mutableStateOf("") }
    var active by rememberSaveable { mutableStateOf(true) }
    var voting by rememberSaveable { mutableStateOf(false) }
    var candidate by rememberSaveable { mutableStateOf("") }
    var video by rememberSaveable { mutableStateOf("") }
    var candidates by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var videos by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var candidateId by rememberSaveable { mutableStateOf(UUID.randomUUID().toString()) }
    var notice by remember { mutableStateOf("") }
    Button(enabled = !busy, onClick = { run { records = NativeApi.call("/admin/events").items("events") } }) { Text("Events Load करें") }
    records.forEach { e -> TextButton(onClick = { id = e.getString("id"); name = e.optString("name"); kind = e.optString("kind"); active = e.optInt("active") == 1; voting = e.optInt("voting") == 1; candidates = emptyList() }) { Text("Edit: ${e.optString("name")}") } }
    TextButton(onClick = { id = UUID.randomUUID().toString(); name = ""; kind = ""; active = true; voting = false; candidates = emptyList() }) { Text("+ नया Event") }
    Field("Event name", name) { name = it }; Field("Event type (अपनी भाषा में)", kind) { kind = it }
    Toggle("Home पर Active Event", active) { active = it }; Toggle("Voting ON", voting) { voting = it }
    Button(enabled = !busy && name.isNotBlank() && kind.isNotBlank(), onClick = { run {
        NativeApi.call("/admin/events/$id", "PUT", json("name" to name.trim(), "kind" to kind.trim(), "active" to active, "voting" to voting)); records = NativeApi.call("/admin/events").items("events"); notice = "Event Save हुआ"; refresh()
    } }) { Text("Save Event") }
    Text("पहले Event save करें, फिर candidates जोड़ें")
    Field("Candidate name", candidate) { candidate = it }
    Text("Performance video (optional)")
    Button(enabled = !busy, onClick = { run { videos = NativeApi.call("/entries").items("entries") } }) { Text("वीडियो चुनें") }
    if (video.isNotBlank()) Text("वीडियो attached ✓")
    TextButton(onClick = { video = "" }) { Text("बिना वीडियो") }
    videos.forEach { e -> FilterChip(selected = video == e.optString("id"), onClick = { video = e.getString("id") }, label = { Text(e.optString("title")) }) }
    TextButton(onClick = { candidateId = UUID.randomUUID().toString(); candidate = ""; video = "" }) { Text("+ नया Candidate") }
    Button(enabled = !busy && candidate.isNotBlank(), onClick = { run {
        NativeApi.call("/admin/events/$id/candidates/$candidateId", "PUT", json("name" to candidate.trim(), "entry_id" to video.trim()))
        candidateId = UUID.randomUUID().toString(); candidate = ""; video = ""; notice = "Candidate Save हुआ"; refresh()
    } }) { Text("Save Candidate") }
    Button(enabled = !busy, onClick = { run { candidates = NativeApi.call("/admin/events/$id/candidates").items("candidates") } }) { Text("Candidates Load करें") }
    candidates.forEach { c ->
        TextButton(onClick = { candidateId = c.getString("id"); candidate = c.optString("name"); video = c.optString("entry_id") }) { Text("Edit ${c.optString("name")}") }
        TextButton(enabled = !busy, onClick = { run {
            NativeApi.call("/admin/events/$id/candidates/${c.getString("id")}", "DELETE")
            candidates = NativeApi.call("/admin/events/$id/candidates").items("candidates"); refresh()
        } }) { Text("Remove candidate (बिना votes)") }
    }
    if (notice.isNotBlank()) Text(notice)
}
