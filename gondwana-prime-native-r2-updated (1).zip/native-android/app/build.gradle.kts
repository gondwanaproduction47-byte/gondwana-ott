plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val apiBase = providers.gradleProperty("API_BASE_URL").orElse("").get()
require(apiBase.isEmpty() || (apiBase.startsWith("https://") && apiBase.none { it == '"' || it == '\\' || it.isWhitespace() })) { "API_BASE_URL must be an HTTPS origin" }
android {
    namespace = "com.gondwana.prime"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.gondwana.prime"
        minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "2.0.0"
        buildConfigField("String", "API_BASE_URL", "\"$apiBase\"")
    }
    buildFeatures { compose = true; buildConfig = true }
    flavorDimensions += "distribution"
    productFlavors {
        create("direct") { dimension = "distribution"; buildConfigField("boolean", "EXTERNAL_PAYMENTS", "true") }
        create("play") { dimension = "distribution"; buildConfigField("boolean", "EXTERNAL_PAYMENTS", "false") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.credentials:credentials:1.5.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.5.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
