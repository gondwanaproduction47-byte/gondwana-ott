import os,time,json,hmac,hashlib
from unittest.mock import Mock
os.environ['DB_PATH']='/tmp/gp-import-test.db'
import app as api
import pytest
from fastapi.testclient import TestClient

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(api,'DB',str(tmp_path/'test.db'));api.init_db()
    with api.db() as c:
        for u,r in [('admin','admin'),('viewer','viewer'),('other','viewer'),('upload','uploader'),('event','event_manager')]:
            c.execute('INSERT INTO users VALUES(?,?,?,?)',(u,u+'@test.com',u,r))
            c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(api.digest(u),u,'device-'+u,int(time.time())+10000))
        c.execute("INSERT INTO uploads VALUES('videos/test.mp4','admin',100,1)")
    monkeypatch.setenv('S3_BUCKET','test')
    storage=Mock();storage.generate_presigned_url.return_value='https://private.example/signed.mp4';storage.head_object.return_value={'ContentLength':100,'ContentType':'video/mp4'}
    monkeypatch.setattr(api,'s3',lambda:storage)
    with TestClient(api.app) as client: yield client

def auth(u='viewer'):return {'Authorization':'Bearer '+u}
def video(c,**kw):
    d=dict(title='Movie',type='movie',object_key='videos/test.mp4',free=True,rent=4900,buy=9900);d.update(kw)
    r=c.put('/api/native/admin/entries/movie',headers=auth('admin'),json=d);assert r.status_code==200,r.text

def test_authorization(client):
    assert client.get('/api/native/me').status_code==401
    assert client.get('/api/native/admin/entries',headers=auth()).status_code==403
    assert client.get('/api/native/admin/report',headers=auth('upload')).status_code==403
    assert client.get('/api/native/admin/entries',headers=auth('upload')).status_code==200
    assert client.post('/api/native/admin/roles',headers=auth('event'),json={'email':'viewer@test.com','role':'admin'}).status_code==403

def test_saved_and_resume_isolation(client):
    video(client)
    assert client.put('/api/native/list/movie',headers=auth()).status_code==200
    assert len(client.get('/api/native/me',headers=auth()).json()['saved'])==1
    assert client.get('/api/native/me',headers=auth('other')).json()['saved']==[]
    p=client.post('/api/native/entries/movie/play',headers=auth()).json()
    body={'play_id':p['play_id'],'position':30000,'duration':120000,'watched':15}
    assert client.post('/api/native/progress/movie',headers=auth('other'),json=body).status_code==404
    assert client.post('/api/native/progress/movie',headers=auth(),json=body).status_code==200
    assert client.get('/api/native/me',headers=auth()).json()['continue'][0]['position']==30000
    assert client.post('/api/native/entries/movie/play',headers=auth()).json()['position']==30000
    client.delete('/api/native/list/movie',headers=auth())
    assert client.get('/api/native/me',headers=auth()).json()['saved']==[]

def test_paid_guard_and_no_public_media(client):
    video(client,free=False)
    assert 'object_key' not in client.get('/api/native/entries').json()['entries'][0]
    assert client.post('/api/native/entries/movie/play',headers=auth()).status_code==402
    with api.db() as c:c.execute('INSERT INTO entitlements VALUES(?,?,?,?)',('o','viewer','movie',int(time.time())-1))
    assert client.post('/api/native/entries/movie/play',headers=auth()).status_code==402
    assert client.post('/api/native/entries/movie/play',headers=auth('admin')).status_code==200

def test_voting_and_active_event(client):
    client.put('/api/native/admin/events/e',headers=auth('event'),json={'name':'Live','kind':'Dance','voting':False})
    client.put('/api/native/admin/events/e/candidates/c',headers=auth('event'),json={'name':'First'})
    assert client.post('/api/native/events/e/vote',headers=auth(),json={'candidate_id':'c'}).status_code==409
    client.put('/api/native/admin/events/e',headers=auth('event'),json={'name':'Live','kind':'Dance','voting':True})
    assert client.post('/api/native/events/e/vote',headers=auth(),json={'candidate_id':'bad'}).status_code==404
    assert client.post('/api/native/events/e/vote',headers=auth(),json={'candidate_id':'c'}).status_code==200
    assert client.post('/api/native/events/e/vote',headers=auth(),json={'candidate_id':'c'}).status_code==409
    assert client.delete('/api/native/admin/events/e/candidates/c',headers=auth('event')).status_code==409
    assert 'votes' not in client.get('/api/native/event').json()['candidates'][0]
    client.put('/api/native/admin/events/next',headers=auth('admin'),json={'name':'New','kind':'Other'})
    assert client.get('/api/native/event').json()['event']['id']=='next'

def test_upload_ownership(client):
    assert client.post('/api/native/admin/uploads',headers=auth(),json={'size':100}).status_code==403
    t=client.post('/api/native/admin/uploads',headers=auth('upload'),json={'size':100}).json()
    assert client.post('/api/native/admin/uploads/complete',headers=auth('admin'),json={'key':t['key']}).status_code==404
    assert client.post('/api/native/admin/uploads/complete',headers=auth('upload'),json={'key':t['key']}).status_code==200
    assert client.put('/api/native/admin/entries/a',headers=auth('upload'),json={'title':'A','object_key':t['key']}).status_code==200
    assert client.put('/api/native/admin/entries/b',headers=auth('upload'),json={'title':'B','object_key':'videos/test.mp4'}).status_code==403

def webhook(c,event,secret='s'):
    raw=json.dumps(event).encode();sig=hmac.new(secret.encode(),raw,hashlib.sha256).hexdigest()
    return c.post('/api/native/payments/webhook',content=raw,headers={'X-Razorpay-Signature':sig})

def test_checkout_webhook_idempotency(client,monkeypatch):
    video(client,free=False,creator='other@test.com',share=25)
    monkeypatch.setattr(api,'PAYMENTS_ENABLED',True)
    for k in ['RAZORPAY_KEY_ID','RAZORPAY_KEY_SECRET','RAZORPAY_WEBHOOK_SECRET']:monkeypatch.setenv(k,'s')
    response=Mock();response.json.return_value={'id':'plink','short_url':'https://rzp.io/test'}
    provider=Mock(return_value=response);monkeypatch.setattr(api.httpx,'post',provider)
    r=client.post('/api/native/checkout',headers=auth(),json={'kind':'rent','entry_id':'movie'})
    assert r.status_code==200,r.text
    oid=r.json()['order_id'];assert provider.call_args.kwargs['json']['amount']==4900
    assert client.post('/api/native/checkout',headers=auth(),json={'kind':'rent','entry_id':'movie'}).json()['order_id']==oid
    e={'event':'payment_link.paid','payload':{'payment':{'entity':{'id':'pay_test'}},'payment_link':{'entity':{'id':'plink','reference_id':oid,'status':'paid','currency':'INR','amount':4900,'amount_paid':4900}}}}
    assert client.post('/api/native/payments/webhook',json=e).status_code==401
    for _ in range(2):assert webhook(client,e).status_code==200
    assert client.post('/api/native/entries/movie/play',headers=auth()).status_code==200
    with api.db() as c:assert c.execute('SELECT count(*) FROM entitlements').fetchone()[0]==1
    assert client.get('/api/native/admin/report',headers=auth('admin')).json()['revenue'][0]['creator_share_paise']==1225
    refund={'event':'refund.processed','payload':{'refund':{'entity':{'payment_id':'pay_test'}}}}
    assert webhook(client,refund).status_code==200
    assert webhook(client,e).status_code==200
    assert client.post('/api/native/entries/movie/play',headers=auth()).status_code==402

def test_webhook_mismatch(client,monkeypatch):
    monkeypatch.setenv('RAZORPAY_WEBHOOK_SECRET','s')
    with api.db() as c:c.execute('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?)',('o','viewer','*','monthly',9900,'plink','','pending',0,'',0))
    e={'event':'payment_link.paid','payload':{'payment_link':{'entity':{'id':'plink','reference_id':'o','status':'paid','currency':'INR','amount':1,'amount_paid':1}}}}
    assert webhook(client,e).status_code==400
    with api.db() as c:assert c.execute('SELECT count(*) FROM entitlements').fetchone()[0]==0

def test_screen_limits_and_device_revoke(client):
    video(client)
    with api.db() as c:c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(api.digest('second'),'viewer','second',int(time.time())+10000))
    assert client.post('/api/native/entries/movie/play',headers=auth()).status_code==200
    assert client.post('/api/native/entries/movie/play',headers=auth('second')).status_code==409
    assert client.delete('/api/native/devices/device-viewer',headers=auth('second')).status_code==200
    assert client.get('/api/native/me',headers=auth()).status_code==401
    assert client.post('/api/native/entries/movie/play',headers=auth('second')).status_code==200

def test_google_server_validation(client,monkeypatch):
    monkeypatch.setattr(api,'GOOGLE_CLIENT_ID','audience')
    verify=Mock(return_value={'sub':'new','email':'new@test.com','name':'New','email_verified':True})
    monkeypatch.setattr(api.id_token,'verify_oauth2_token',verify)
    r=client.post('/api/native/auth/google',json={'id_token':'fake-for-unit-test','device':'a'})
    assert r.status_code==200,r.text
    assert verify.call_args.args[2]=='audience'
    token=r.json()['token']
    assert client.get('/api/native/me',headers=auth(token)).json()['user']['role']=='viewer'
    assert client.post('/api/native/logout',headers=auth(token)).status_code==200
    assert client.get('/api/native/me',headers=auth(token)).status_code==401
    verify.side_effect=ValueError('invalid')
    assert client.post('/api/native/auth/google',json={'id_token':'fake-for-unit-test','device':'a'}).status_code==401

def test_google_device_limit_and_reuse(client,monkeypatch):
    monkeypatch.setattr(api,'GOOGLE_CLIENT_ID','aud')
    monkeypatch.setattr(api,'MAX_DEVICES',1)
    monkeypatch.setattr(api.id_token,'verify_oauth2_token',Mock(return_value={'sub':'viewer','email':'viewer@test.com','email_verified':True}))
    assert client.post('/api/native/auth/google',json={'id_token':'fake-test-token','device':'another'}).status_code==409
    r=client.post('/api/native/auth/google',json={'id_token':'fake-test-token','device':'device-viewer'})
    assert r.status_code==200
    assert client.get('/api/native/me',headers=auth()).status_code==401
    assert client.get('/api/native/me',headers=auth(r.json()['token'])).status_code==200

def test_membership_stacks_and_expiration(client,monkeypatch):
    monkeypatch.setenv('RAZORPAY_WEBHOOK_SECRET','s')
    future=int(time.time())+1000
    with api.db() as c:
        c.execute('INSERT INTO entitlements VALUES(?,?,?,?)',('previous','viewer','*',future))
        c.execute('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?)',('renew','viewer','*','monthly',9900,'plink2','','pending',0,'',0))
    e={'event':'payment_link.paid','payload':{'payment':{'entity':{'id':'pay2'}},'payment_link':{'entity':{'id':'plink2','reference_id':'renew','status':'paid','currency':'INR','amount':9900,'amount_paid':9900}}}}
    assert webhook(client,e).status_code==200
    with api.db() as c:assert c.execute("SELECT expires FROM entitlements WHERE order_id='renew'").fetchone()[0]==future+2592000

def test_soft_delete_hides_saved_video(client):
    video(client)
    client.put('/api/native/list/movie',headers=auth())
    assert client.delete('/api/native/admin/entries/movie',headers=auth('upload')).status_code==403
    assert client.delete('/api/native/admin/entries/movie',headers=auth('admin')).status_code==200
    assert client.get('/api/native/entries').json()['entries']==[]
    assert client.get('/api/native/me',headers=auth()).json()['saved']==[]
    assert client.post('/api/native/entries/movie/play',headers=auth()).status_code==404

def test_payment_disabled_and_upload_size(client,monkeypatch):
    monkeypatch.setattr(api,'PAYMENTS_ENABLED',False)
    assert client.post('/api/native/checkout',headers=auth(),json={'kind':'monthly'}).status_code==503
    assert client.post('/api/native/admin/uploads',headers=auth('admin'),json={'size':5_000_000_001}).status_code==422

def test_heartbeat_rechecks_entitlement_and_screens(client):
    video(client,free=False)
    with api.db() as c:
        c.execute('INSERT INTO entitlements VALUES(?,?,?,?)',('r','viewer','movie',int(time.time())+1000))
    p=client.post('/api/native/entries/movie/play',headers=auth()).json()
    body={'play_id':p['play_id'],'position':1000,'duration':100000,'watched':0}
    with api.db() as c:c.execute("UPDATE entitlements SET expires=0 WHERE order_id='r'")
    assert client.post('/api/native/progress/movie',headers=auth(),json=body).status_code==402
    with api.db() as c:
        c.execute("UPDATE entitlements SET expires=? WHERE order_id='r'",(int(time.time())+1000,))
        c.execute('INSERT INTO plays(id,user_id,entry_id,device,last_seen) VALUES(?,?,?,?,?)',('another','viewer','movie','other-device',int(time.time())))
    assert client.post('/api/native/progress/movie',headers=auth(),json=body).status_code==409
