"""Gondwana Prime reference API. Single-instance SQLite; private S3/R2 media."""
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import time
from contextlib import contextmanager
from typing import Literal

import boto3
import httpx
from botocore.config import Config
from fastapi import FastAPI, Depends, Header, HTTPException, Request
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token
from pydantic import BaseModel, Field

app = FastAPI(title="Gondwana Prime Native API", version="2.0")
DB = os.getenv("DB_PATH", "gondwana.db")
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "").lower()
MAX_DEVICES = int(os.getenv("MAX_DEVICES", "3"))
MAX_SCREENS = int(os.getenv("MAX_SCREENS", "1"))
PAYMENTS_ENABLED = os.getenv("PAYMENTS_ENABLED", "false").lower() == "true"
PLANS = {"monthly": int(os.getenv("MONTHLY_PAISE", "9900")), "yearly": int(os.getenv("YEARLY_PAISE", "99900"))}

@contextmanager
def db():
    c = sqlite3.connect(DB, timeout=20)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    try:
        yield c
        c.commit()
    except BaseException:
        c.rollback()
        raise
    finally:
        c.close()

def init_db():
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT NOT NULL,name TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'viewer');
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),device TEXT,expires INTEGER,UNIQUE(user_id,device));
        CREATE TABLE IF NOT EXISTS entries(id TEXT PRIMARY KEY,title TEXT,type TEXT,description TEXT,object_key TEXT,free INTEGER,rent INTEGER,buy INTEGER,creator TEXT,share INTEGER,series TEXT,episode INTEGER,deleted INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS uploads(key TEXT PRIMARY KEY,user_id TEXT,size INTEGER,completed INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS saved(user_id TEXT,entry_id TEXT REFERENCES entries(id),PRIMARY KEY(user_id,entry_id));
        CREATE TABLE IF NOT EXISTS progress(user_id TEXT,entry_id TEXT REFERENCES entries(id),position INTEGER,duration INTEGER,updated INTEGER,PRIMARY KEY(user_id,entry_id));
        CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,name TEXT,kind TEXT,active INTEGER,voting INTEGER);
        CREATE TABLE IF NOT EXISTS candidates(id TEXT PRIMARY KEY,event_id TEXT REFERENCES events(id),name TEXT,entry_id TEXT);
        CREATE TABLE IF NOT EXISTS votes(user_id TEXT,event_id TEXT,candidate_id TEXT,PRIMARY KEY(user_id,event_id));
        CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,user_id TEXT,entry_id TEXT,kind TEXT,amount INTEGER,provider_id TEXT UNIQUE,url TEXT,status TEXT,created INTEGER,creator TEXT,share INTEGER);
        CREATE TABLE IF NOT EXISTS entitlements(order_id TEXT PRIMARY KEY,user_id TEXT,entry_id TEXT,expires INTEGER);
        CREATE TABLE IF NOT EXISTS plays(id TEXT PRIMARY KEY,user_id TEXT,entry_id TEXT,device TEXT,last_seen INTEGER,watched INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS payment_ids(payment_id TEXT PRIMARY KEY,order_id TEXT NOT NULL);
        ''')

def fail(code, message):
    raise HTTPException(code, message)

def one(c, sql, values=()):
    r = c.execute(sql, values).fetchone()
    return dict(r) if r else None

def rows(c, sql, values=()):
    return [dict(r) for r in c.execute(sql, values)]

def digest(token):
    return hashlib.sha256(token.encode()).hexdigest()

def user(authorization: str = Header(default="")):
    if not authorization.startswith("Bearer "):
        fail(401, "कृपया Google से login करें")
    with db() as c:
        u = one(c, "SELECT u.*,s.device FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?", (digest(authorization[7:]), int(time.time())))
    if not u:
        fail(401, "Login expired. कृपया फिर login करें")
    return u

def role(u, *allowed):
    if u["role"] not in allowed:
        fail(403, "आपके खाते में इस कार्य का अधिकार नहीं है")

from functools import lru_cache

@lru_cache(maxsize=1)
def s3():
    needed = ["S3_ENDPOINT", "S3_ACCESS_KEY", "S3_SECRET_KEY", "S3_BUCKET"]
    if not all(os.getenv(k) for k in needed):
        fail(503, "Video storage configuration pending")
    return boto3.client("s3", endpoint_url=os.environ["S3_ENDPOINT"], aws_access_key_id=os.environ["S3_ACCESS_KEY"], aws_secret_access_key=os.environ["S3_SECRET_KEY"], region_name="auto", config=Config(signature_version="s3v4"))

class Login(BaseModel):
    id_token: str = Field(min_length=10, max_length=10000)
    device: str = Field(min_length=1, max_length=100)

@app.post("/api/native/auth/google")
def login(data: Login):
    if not GOOGLE_CLIENT_ID:
        fail(503, "Google backend client ID configuration pending")
    try:
        info = id_token.verify_oauth2_token(data.id_token, google_requests.Request(), GOOGLE_CLIENT_ID)
    except Exception:
        fail(401, "Google token verification failed")
    if not info.get("email_verified"):
        fail(401, "Verified Google email required")
    uid, email = info["sub"], info["email"].lower()
    now, token = int(time.time()), secrets.token_urlsafe(40)
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        c.execute("DELETE FROM sessions WHERE expires<=?", (now,))
        c.execute("INSERT INTO users(id,email,name,role) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email,name=excluded.name", (uid,email,info.get("name",email),"admin" if email == ADMIN_EMAIL else "viewer"))
        existing = one(c,"SELECT * FROM sessions WHERE user_id=? AND device=?",(uid,data.device))
        count = c.execute("SELECT count(*) FROM sessions WHERE user_id=?",(uid,)).fetchone()[0]
        if not existing and count >= MAX_DEVICES:
            fail(409,"Device limit reached. दूसरे device के Account से logout करें")
        c.execute("INSERT OR REPLACE INTO sessions VALUES(?,?,?,?)",(digest(token),uid,data.device,now+604800))
        profile=one(c,"SELECT * FROM users WHERE id=?",(uid,))
    return {"token":token,"user":profile}

@app.post("/api/native/logout")
def logout(u=Depends(user)):
    with db() as c:
        c.execute("DELETE FROM sessions WHERE user_id=? AND device=?",(u["id"],u["device"]))
        c.execute("DELETE FROM plays WHERE user_id=? AND device=?",(u["id"],u["device"]))
    return {"ok":True}

@app.get("/api/native/config")
def config():
    return {"payments_enabled":PAYMENTS_ENABLED,"plans":PLANS,"max_devices":MAX_DEVICES,"max_screens":MAX_SCREENS}

PUBLIC_FIELDS = "id,title,type,description,free,rent,buy,series,episode"
@app.get("/api/native/entries")
def entries():
    with db() as c:
        return {"entries":rows(c,f"SELECT {PUBLIC_FIELDS} FROM entries WHERE deleted=0 ORDER BY rowid DESC")}

def entry(c, eid):
    e=one(c,"SELECT * FROM entries WHERE id=? AND deleted=0",(eid,))
    if not e: fail(404,"Video not found")
    return e

def access(c, u, e):
    return e["free"] or u["role"] == "admin" or one(c,"SELECT order_id FROM entitlements WHERE user_id=? AND (entry_id=? OR entry_id='*') AND expires>?",(u["id"],e["id"],int(time.time())))

@app.post("/api/native/entries/{eid}/play")
def play(eid: str,u=Depends(user)):
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        e=entry(c,eid)
        if not access(c,u,e): fail(402,"इस वीडियो के लिए Rent, Buy या Membership लें")
        now=int(time.time())
        screens=c.execute("SELECT count(DISTINCT device) FROM plays WHERE user_id=? AND device!=? AND last_seen>?",(u["id"],u["device"],now-60)).fetchone()[0]
        if screens>=MAX_SCREENS: fail(409,"एक साथ चलने वाली screens की सीमा पूरी है")
        client=s3()
        url=client.generate_presigned_url("get_object",Params={"Bucket":os.environ["S3_BUCKET"],"Key":e["object_key"]},ExpiresIn=max(300, min(int(os.getenv("PLAYBACK_URL_TTL_SECONDS", "3600")), 14400)))
        pid=secrets.token_hex(16)
        c.execute("INSERT INTO plays(id,user_id,entry_id,device,last_seen) VALUES(?,?,?,?,?)",(pid,u["id"],eid,u["device"],now))
        p=one(c,"SELECT position,duration FROM progress WHERE user_id=? AND entry_id=?",(u["id"],eid))
    return {"url":url,"play_id":pid,"position":p["position"] if p and p["position"]<p["duration"]-10000 else 0}

class Progress(BaseModel):
    play_id:str
    position:int=Field(ge=0,le=86400000)
    duration:int=Field(ge=0,le=86400000)
    watched:int=Field(default=0,ge=0,le=30)
    stop:bool=False

@app.post("/api/native/progress/{eid}")
def progress(eid:str,data:Progress,u=Depends(user)):
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        p=one(c,"SELECT * FROM plays WHERE id=? AND user_id=? AND entry_id=? AND device=?",(data.play_id,u["id"],eid,u["device"]))
        if not p: fail(404,"Playback session not found")
        now=int(time.time())
        if not data.stop:
            if not access(c,u,entry(c,eid)): fail(402,'Playback access expired')
            others=c.execute('SELECT count(DISTINCT device) FROM plays WHERE user_id=? AND device!=? AND last_seen>?',(u['id'],u['device'],now-60)).fetchone()[0]
            if others>=MAX_SCREENS: fail(409,'Another screen is playing; stop it before resuming')
        c.execute("INSERT INTO progress VALUES(?,?,?,?,?) ON CONFLICT(user_id,entry_id) DO UPDATE SET position=excluded.position,duration=excluded.duration,updated=excluded.updated",(u["id"],eid,min(data.position,data.duration) if data.duration else data.position,data.duration,now))
        watched=min(data.watched,max(0,now-p["last_seen"]))
        c.execute("UPDATE plays SET last_seen=?,watched=watched+? WHERE id=?",(0 if data.stop else now,watched,data.play_id))
    return {"ok":True}

@app.get("/api/native/me")
def me(u=Depends(user)):
    with db() as c:
        return {"user":{k:u[k] for k in ("id","email","name","role")},"saved":rows(c,f"SELECT {','.join('e.'+k for k in PUBLIC_FIELDS.split(','))} FROM entries e JOIN saved s ON s.entry_id=e.id WHERE s.user_id=? AND e.deleted=0",(u["id"],)),"continue":rows(c,"SELECT e.id,e.title,p.position,p.duration FROM progress p JOIN entries e ON e.id=p.entry_id WHERE p.user_id=? AND e.deleted=0 AND p.position>0 AND p.position<p.duration-10000 ORDER BY p.updated DESC",(u["id"],)),"orders":rows(c,"SELECT id,kind,amount,status,created FROM orders WHERE user_id=? ORDER BY created DESC",(u["id"],)),"devices":rows(c,"SELECT device,expires FROM sessions WHERE user_id=? AND expires>?",(u["id"],int(time.time()))),"entitlements":rows(c,"SELECT entry_id,expires FROM entitlements WHERE user_id=? AND expires>?",(u["id"],int(time.time())))}

@app.delete("/api/native/devices/{device}")
def remove_device(device:str,u=Depends(user)):
    with db() as c:
        c.execute("DELETE FROM sessions WHERE user_id=? AND device=?",(u["id"],device))
        c.execute("UPDATE plays SET last_seen=0 WHERE user_id=? AND device=?",(u["id"],device))
    return {"ok":True}

@app.put("/api/native/list/{eid}")
def save(eid:str,u=Depends(user)):
    with db() as c:
        entry(c,eid)
        c.execute("INSERT OR IGNORE INTO saved VALUES(?,?)",(u["id"],eid))
    return {"ok":True}

@app.delete("/api/native/list/{eid}")
def unsave(eid:str,u=Depends(user)):
    with db() as c: c.execute("DELETE FROM saved WHERE user_id=? AND entry_id=?",(u["id"],eid))
    return {"ok":True}

@app.get("/api/native/event")
def event():
    with db() as c:
        e=one(c,"SELECT * FROM events WHERE active=1")
        return {"event":e,"candidates":rows(c,"SELECT id,name,entry_id FROM candidates WHERE event_id=? ORDER BY name",(e["id"],)) if e else []}

class Vote(BaseModel):
    candidate_id:str

@app.post("/api/native/events/{event_id}/vote")
def vote(event_id:str,data:Vote,u=Depends(user)):
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        e=one(c,"SELECT * FROM events WHERE id=? AND active=1 AND voting=1",(event_id,))
        if not e: fail(409,"Voting अभी बंद है")
        if not one(c,"SELECT id FROM candidates WHERE id=? AND event_id=?",(data.candidate_id,event_id)): fail(404,"Candidate not found")
        if one(c,"SELECT * FROM votes WHERE user_id=? AND event_id=?",(u["id"],event_id)): fail(409,"आप इस इवेंट में पहले ही vote कर चुके हैं")
        c.execute("INSERT INTO votes VALUES(?,?,?)",(u["id"],event_id,data.candidate_id))
    return {"ok":True}

class EntryInput(BaseModel):
    title:str=Field(min_length=1,max_length=200)
    type:Literal['movie','series','event']='movie'
    description:str=Field(default='',max_length=3000)
    object_key:str=Field(min_length=1,max_length=300)
    free:bool=True
    rent:int=Field(default=0,ge=0,le=100000000)
    buy:int=Field(default=0,ge=0,le=100000000)
    creator:str=Field(default='',max_length=200)
    share:int=Field(default=0,ge=0,le=100)
    series:str=Field(default='',max_length=200)
    episode:int=Field(default=0,ge=0)

@app.get("/api/native/admin/entries")
def admin_entries(u=Depends(user)):
    role(u,'admin','uploader')
    with db() as c: return {"entries":rows(c,"SELECT * FROM entries WHERE deleted=0 ORDER BY title")}

@app.put("/api/native/admin/entries/{eid}")
def put_entry(eid:str,data:EntryInput,u=Depends(user)):
    role(u,'admin','uploader')
    with db() as c:
        upload=one(c,"SELECT * FROM uploads WHERE key=? AND completed=1",(data.object_key,))
        if not upload: fail(400,"पहले वीडियो upload पूरा करें")
        if u['role']!='admin' and upload['user_id']!=u['id']: fail(403,"Upload ownership required")
        old=one(c,"SELECT * FROM entries WHERE id=?",(eid,))
        if old and u['role']!='admin':
            original=one(c,"SELECT user_id FROM uploads WHERE key=?",(old['object_key'],))
            if not original or original['user_id']!=u['id']: fail(403,"Only your own uploads can be edited")
        if u['role']!='admin' and (data.creator or data.share): fail(403,"Only main Admin can set revenue sharing")
        if data.creator and not one(c,"SELECT id FROM users WHERE email=?",(data.creator.lower(),)): fail(400,"Creator must login once before assignment")
        vals=data.model_dump(); vals['creator']=data.creator.lower()
        c.execute("INSERT INTO entries(id,title,type,description,object_key,free,rent,buy,creator,share,series,episode) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,type=excluded.type,description=excluded.description,object_key=excluded.object_key,free=excluded.free,rent=excluded.rent,buy=excluded.buy,creator=excluded.creator,share=excluded.share,series=excluded.series,episode=excluded.episode",(eid,*vals.values()))
    return {"ok":True}

@app.delete("/api/native/admin/entries/{eid}")
def delete_entry(eid:str,u=Depends(user)):
    role(u,'admin')
    with db() as c: c.execute("UPDATE entries SET deleted=1 WHERE id=?",(eid,))
    return {"ok":True}

class Upload(BaseModel):
    size:int=Field(gt=0,le=5_000_000_000)
    mime:Literal['video/mp4']='video/mp4'

@app.post("/api/native/admin/uploads")
def upload(data:Upload,u=Depends(user)):
    role(u,'admin','uploader')
    key='videos/'+secrets.token_hex(20)+'.mp4'
    url=s3().generate_presigned_url('put_object',Params={'Bucket':os.environ['S3_BUCKET'],'Key':key,'ContentType':data.mime},ExpiresIn=3600)
    with db() as c: c.execute("INSERT INTO uploads(key,user_id,size) VALUES(?,?,?)",(key,u['id'],data.size))
    return {'key':key,'url':url}

class Complete(BaseModel):
    key:str

@app.post("/api/native/admin/uploads/complete")
def complete(data:Complete,u=Depends(user)):
    role(u,'admin','uploader')
    with db() as c:
        r=one(c,"SELECT * FROM uploads WHERE key=? AND user_id=?",(data.key,u['id']))
        if not r: fail(404,'Upload not found')
        meta=s3().head_object(Bucket=os.environ['S3_BUCKET'],Key=data.key)
        if meta['ContentLength']!=r['size'] or meta.get('ContentType')!='video/mp4': fail(400,'Upload size/type mismatch')
        c.execute("UPDATE uploads SET completed=1 WHERE key=?",(data.key,))
    return {'ok':True}

class EventInput(BaseModel):
    name:str=Field(min_length=1,max_length=200)
    kind:str=Field(min_length=1,max_length=100)
    active:bool=True
    voting:bool=False

@app.get('/api/native/admin/events')
def all_events(u=Depends(user)):
    role(u,'admin','event_manager')
    with db() as c: return {'events':rows(c,'SELECT * FROM events ORDER BY rowid DESC')}

@app.put('/api/native/admin/events/{eid}')
def put_event(eid:str,data:EventInput,u=Depends(user)):
    role(u,'admin','event_manager')
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        if data.active: c.execute('UPDATE events SET active=0')
        c.execute('INSERT INTO events VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,kind=excluded.kind,active=excluded.active,voting=excluded.voting',(eid,data.name,data.kind,data.active,data.voting))
    return {'ok':True}

class CandidateInput(BaseModel):
    name:str=Field(min_length=1,max_length=200)
    entry_id:str=''

@app.put('/api/native/admin/events/{eid}/candidates/{cid}')
def put_candidate(eid:str,cid:str,data:CandidateInput,u=Depends(user)):
    role(u,'admin','event_manager')
    with db() as c:
        if not one(c,'SELECT id FROM events WHERE id=?',(eid,)): fail(404,'Event not found')
        existing=one(c,'SELECT event_id FROM candidates WHERE id=?',(cid,))
        if existing and existing['event_id']!=eid: fail(409,'Candidate belongs to another event')
        if data.entry_id: entry(c,data.entry_id)
        c.execute('INSERT INTO candidates VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,entry_id=excluded.entry_id',(cid,eid,data.name,data.entry_id))
    return {'ok':True}

@app.delete('/api/native/admin/events/{eid}/candidates/{cid}')
def delete_candidate(eid:str,cid:str,u=Depends(user)):
    role(u,'admin','event_manager')
    with db() as c:
        if one(c,'SELECT * FROM votes WHERE candidate_id=?',(cid,)): fail(409,'Votes exist: candidate cannot be removed')
        c.execute('DELETE FROM candidates WHERE id=? AND event_id=?',(cid,eid))
    return {'ok':True}

class RoleInput(BaseModel):
    email:str
    role:Literal['viewer','uploader','event_manager','creator','admin']

@app.post('/api/native/admin/roles')
def set_role(data:RoleInput,u=Depends(user)):
    role(u,'admin')
    if data.email.lower()==ADMIN_EMAIL: fail(409,'Bootstrap Admin role is protected')
    with db() as c:
        if not one(c,'SELECT id FROM users WHERE email=?',(data.email.lower(),)): fail(404,'User must login once first')
        c.execute('UPDATE users SET role=? WHERE email=?',(data.role,data.email.lower()))
    return {'ok':True}

@app.get('/api/native/admin/report')
def report(u=Depends(user)):
    role(u,'admin','event_manager')
    with db() as c:
        result={'votes':rows(c,'SELECT e.name AS event,c.name,count(v.user_id) AS votes FROM candidates c JOIN events e ON e.id=c.event_id LEFT JOIN votes v ON v.candidate_id=c.id GROUP BY c.id')}
        if u['role']=='admin':
            result['analytics']=rows(c,'SELECT e.title,count(p.id) AS starts,count(DISTINCT p.user_id) AS viewers,coalesce(sum(p.watched),0) AS watched_seconds FROM entries e LEFT JOIN plays p ON p.entry_id=e.id GROUP BY e.id')
            result['dropoff']=rows(c,'SELECT e.title,p.position,p.duration,count(*) AS viewers FROM progress p JOIN entries e ON e.id=p.entry_id GROUP BY e.id,p.position,p.duration')
            result['revenue']=rows(c,"SELECT creator,sum(amount) AS gross_paise,sum(amount*share/100) AS creator_share_paise FROM orders WHERE status='paid' GROUP BY creator")
        return result

@app.get('/api/native/creator/revenue')
def creator_revenue(u=Depends(user)):
    role(u,'creator','admin')
    with db() as c:
        return {'sales':rows(c,"SELECT id,entry_id,kind,amount,share,amount*share/100 AS share_paise,created FROM orders WHERE creator=? AND status='paid' ORDER BY created DESC",(u['email'],)),'note':'Gross sales allocation; payout is manual. Subscription pooling is not allocated.'}

class Checkout(BaseModel):
    kind:Literal['rent','buy','monthly','yearly']
    entry_id:str=''

@app.post('/api/native/checkout')
def checkout(data:Checkout,u=Depends(user)):
    if not PAYMENTS_ENABLED: fail(503,'Payment setup pending')
    kid,secret=os.getenv('RAZORPAY_KEY_ID'),os.getenv('RAZORPAY_KEY_SECRET')
    if not kid or not secret: fail(503,'Payment provider configuration pending')
    creator,share='',0
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        if data.kind in PLANS: amount=PLANS[data.kind]; eid='*'
        else:
            e=entry(c,data.entry_id); amount=e[data.kind]; eid=e['id']; creator=e['creator']; share=e['share']
            if e['free'] or amount<=0: fail(400,'This purchase option is unavailable')
        creating=one(c,"SELECT id FROM orders WHERE user_id=? AND entry_id=? AND kind=? AND status='creating' AND created>?",(u['id'],eid,data.kind,int(time.time())-300))
        if creating: fail(409,'Payment link is being created. Please wait and retry.')
        # Reuse pending links to prevent double taps creating duplicate payments.
        previous=one(c,"SELECT * FROM orders WHERE user_id=? AND entry_id=? AND kind=? AND status='pending' AND created>? ORDER BY created DESC",(u['id'],eid,data.kind,int(time.time())-1800))
        if previous: return {'order_id':previous['id'],'url':previous['url']}
        oid=secrets.token_hex(16)
        c.execute('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?,?)',(oid,u['id'],eid,data.kind,amount,None,'','creating',int(time.time()),creator,share))
    try:
        response=httpx.post('https://api.razorpay.com/v1/payment_links',auth=(kid,secret),json={'amount':amount,'currency':'INR','accept_partial':False,'reference_id':oid,'description':'Gondwana Prime '+data.kind,'expire_by':int(time.time())+3600},timeout=25)
        response.raise_for_status(); link=response.json()
    except Exception:
        with db() as c: c.execute("UPDATE orders SET status='failed' WHERE id=?",(oid,))
        fail(502,'Payment service unavailable; please retry')
    with db() as c: c.execute("UPDATE orders SET provider_id=?,url=?,status='pending' WHERE id=?",(link['id'],link['short_url'],oid))
    return {'order_id':oid,'url':link['short_url']}

@app.post('/api/native/payments/webhook')
async def webhook(request:Request,x_razorpay_signature:str=Header(default='')):
    secret=os.getenv('RAZORPAY_WEBHOOK_SECRET','')
    if not secret: fail(503,'Webhook configuration pending')
    raw=await request.body()
    if not hmac.compare_digest(hmac.new(secret.encode(),raw,hashlib.sha256).hexdigest(),x_razorpay_signature): fail(401,'Invalid signature')
    try: event=json.loads(raw)
    except ValueError: fail(400,'Invalid JSON')
    if event.get('event') == 'refund.processed':
        refund=event.get('payload',{}).get('refund',{}).get('entity',{})
        with db() as c:
            c.execute('BEGIN IMMEDIATE')
            known=one(c,'SELECT order_id FROM payment_ids WHERE payment_id=?',(refund.get('payment_id',''),))
            if not known: fail(409,'Payment mapping not received yet; retry webhook')
            c.execute("UPDATE orders SET status='refunded' WHERE id=?",(known['order_id'],))
            c.execute('DELETE FROM entitlements WHERE order_id=?',(known['order_id'],))
        return {'ok':True}
    if event.get('event')!='payment_link.paid': return {'ignored':True}
    link=event.get('payload',{}).get('payment_link',{}).get('entity',{})
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        o=one(c,'SELECT * FROM orders WHERE id=?',(link.get('reference_id',''),))
        if not o: fail(404,'Unknown order')
        if o['status'] in ('paid','refunded'): return {'ok':True}
        if link.get('id')!=o['provider_id'] or link.get('status')!='paid' or link.get('currency')!='INR' or link.get('amount_paid')!=o['amount'] or link.get('amount')!=o['amount']: fail(400,'Payment mismatch')
        payment=event.get('payload',{}).get('payment',{}).get('entity',{})
        payment_id=payment.get('id')
        if not payment_id: fail(400,'Payment ID missing')
        c.execute('INSERT INTO payment_ids VALUES(?,?)',(payment_id,o['id']))
        now=int(time.time())
        base=now
        if o['kind'] in PLANS:
            base=max(now,c.execute("SELECT coalesce(max(expires),0) FROM entitlements WHERE user_id=? AND entry_id='*'",(o['user_id'],)).fetchone()[0])
        expires=base+{'rent':172800,'buy':3153600000,'monthly':2592000,'yearly':31536000}[o['kind']]
        c.execute('INSERT INTO entitlements VALUES(?,?,?,?)',(o['id'],o['user_id'],o['entry_id'],expires))
        c.execute("UPDATE orders SET status='paid' WHERE id=?",(o['id'],))
    return {'ok':True}

@app.get('/health')
def health(): return {'status':'ok'}

init_db()

@app.get('/api/native/admin/events/{eid}/candidates')
def admin_candidates(eid:str,u=Depends(user)):
    role(u,'admin','event_manager')
    with db() as c: return {'candidates':rows(c,'SELECT * FROM candidates WHERE event_id=? ORDER BY name',(eid,))}
