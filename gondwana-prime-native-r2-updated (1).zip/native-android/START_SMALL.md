# शुरुआत का चुना हुआ setup

यह version पहले Google Login और वीडियो upload/playback जाँचने के लिए तैयार है।
Render, Cloudflare या Google खाते में अभी कोई resource बनाया नहीं गया है।

| हिस्सा | Project configuration |
| --- | --- |
| Backend | Render का छोटा paid compute: 0.5 CPU / 512 MB; एक instance |
| Database | 1 GB persistent disk; SQLite /var/data/gondwana.db |
| Videos | Private Cloudflare R2 bucket; Standard storage का free allowance |
| Login | Existing Google web Client ID; Android SHA-1 जोड़ना बाकी |
| Payment | PAYMENTS_ENABLED=false; Razorpay keys अभी नहीं चाहिए |
| Devices | प्रति account 3 registered devices; एक concurrent screen |
| Deployment updates | Manual deploy; auto-deploy बंद |

## पहले क्या करना है

1. इस folder के contents को अपने Git repository के root में रखें। `render.yaml`
   उसी root पर होना चाहिए, `backend/` के अंदर नहीं।
2. Render account में **New → Blueprint** से repository चुनें। Blueprint छोटा paid
   compute और 1 GB disk दिखाएगा। प्रदर्शित वर्तमान monthly estimate देखकर लागू करें।
   पहले बताया गया $7.25/month आधार अनुमान था; checkout का वर्तमान quote लागू होगा।
3. Deployment के environment prompts में `ADMIN_EMAIL` और R2 के
   endpoint, bucket, access key और secret key भरें।
   Google Client ID पहले से दिया है। Secrets केवल Render के private environment fields में भरें।
4. Cloudflare में R2 Standard का **private bucket** बनाएँ। Public access चालू न करें।
   Bucket-scoped read/write credentials उपयोग करें। 10 GB-month free allowance unlimited
   storage नहीं है; कुछ छोटे MP4 videos से शुरू करें और R2 usage dashboard देखें।
   R2 activation के लिए billing details माँगी जा सकती हैं।
5. Deploy होने पर Render का वास्तविक HTTPS URL `API_BASE_URL` में रखें और Android
   APK build करें। कोई अनुमानित URL इस ZIP में नहीं डाला गया है।
6. Google Cloud में package `com.gondwana.prime` और APK signing certificate का SHA-1
   Android OAuth client में जोड़ें। Login करके Account में Admin Panel जाँचें।

## पहला परीक्षण

- Main Admin Google login करता है।
- Admin एक छोटा H.264/AAC MP4 upload करता है और **Free video ON** रखकर save करता है।
- दूसरे Google account से login करके वही वीडियो चलाएँ।
- My List में जोड़ें, कुछ देर देखें, वापस आकर Continue Watching जाँचें।
- Backend redeploy/restart के बाद users, videos की metadata और saved list बनी रहनी चाहिए।
- कोई Rent/Buy checkout button नहीं दिखना चाहिए; server checkout request भी रोकता है।

पहले paid video न बनाएँ: payments बंद होने पर साधारण नए user को उसका access नहीं मिलेगा।
1 GB disk में user/metadata रहती है; video files R2 में जाती हैं। Backups अलग से रखें।
यह small pilot configuration है, 100,000 viewers के लिए capacity guarantee नहीं।

## उसके बाद Razorpay

Login और playback सही चलने के बाद `SETUP.md` के Payment setup वाले चरण अपनाएँ।
पहले test keys और signed webhook जाँचें। फिर merchant activation और live credentials के
बाद payments चालू करें। Blueprint में `PAYMENTS_ENABLED` भी true करें ताकि अगली sync उसे
फिर false न करे। Standard setup में recurring debit और automatic creator payouts नहीं हैं।

## Deployment connection

Render integration अभी connected नहीं है। ChatGPT से deployment आगे कराने के लिए Render
plugin install/connect करें। Git repository का access और R2/Google configuration भी आवश्यक हैं।
Secrets चैट में paste न करें।

References:
- https://render.com/docs/blueprint-spec
- https://render.com/docs/disks
- https://developers.cloudflare.com/r2/pricing/
