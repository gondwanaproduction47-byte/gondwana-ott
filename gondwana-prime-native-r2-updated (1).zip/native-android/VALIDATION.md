# Validation — 15 October 2026

## Backend

`cd backend && python -m pytest -q`

**14 tests passed** on Python 3.12. The tests use an isolated temporary SQLite database.
Google verification, S3 and Razorpay HTTP calls are mocked. They do not prove live credentials work.
One dependency deprecation warning from the FastAPI/Starlette test client is non-failing.

Covered:

- Authentication and role restrictions; uploader ownership and upload bounds.
- Per-user My List and saved resume-position isolation.
- Paid-video denial without valid entitlement; public catalog contains no private object keys.
- Single active event, closed voting, invalid candidates, one vote per account, candidate deletion guard.
- Server-derived checkout amount, pending-link reuse, invalid signature rejection, amount mismatch.
- Duplicate webhook idempotency, refunds and protection against replay re-granting refunded access.
- Device revocation, screen limits, Google audience verification, logout and device-session replacement.
- Membership extension, soft-deleted catalog exclusion, and playback heartbeat rechecking access/screens.

## Android

Gradle 8.10.2, JDK 17, Android SDK 35. Final clean offline build succeeded after all source changes. Both debug variants were built:

- `assembleDirectDebug` — external checkout UI enabled (backend must also enable payments).
- `assemblePlayDebug` — external checkout UI disabled.

The compiled builds use an empty backend URL so that no unknown server is called.
Set `API_BASE_URL` and rebuild for a real test installation. These are source-level/build checks,
not emulator, screenshot, Google sign-in, streaming or payment end-to-end tests.

## Not validated or deployed

- No change has been deployed to the existing website or backend.
- No APK has been installed on a user's phone or published to Play Store.
- No real Google account, R2 object, Razorpay test/live transaction or webhook delivery was used.
- No release signing, Play Billing, recurring mandate, automatic creator payout, DRM, live ingest,
  transcoding, background/resumable upload or high-concurrency load test is included.

Follow SETUP.md and its real-device acceptance checklist before launch.

## Small pilot deployment configuration update

- `render.yaml` validated against the current official Render JSON Schema.
- Verified one 0.5 CPU / 512 MB service, one instance, 1 GB disk, database path on the disk, private credential prompts and payments OFF.
- Targeted payment-disabled test passed (1 test).
- Android/backend application source is unchanged from the prior successful builds and 14-test run.
- No Render service, R2 bucket or Google OAuth configuration was created remotely. Render connection is still required.
