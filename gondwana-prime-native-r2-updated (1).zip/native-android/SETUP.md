# Setup — प्रोजेक्ट से चलने वाले ऐप तक

Selected pilot configuration: see `START_SMALL.md` and root `render.yaml`.
Payments stay disabled until login and playback acceptance is complete.

## 1. Backend server

`backend/` नया server है। इसे पुराने website URL से अपने-आप connection नहीं मिलेगा।
पुराना data चाहिए तो उसके schema के अनुसार अलग migration आवश्यक है।

Local server setup (Python 3.12):

```bash
cd backend
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with real configuration; keep it private.
set -a
. ./.env
set +a
python -m uvicorn app:app --host 0.0.0.0 --port 8000 --workers 1
```

For local testing set DB_PATH to a writable local file, e.g. `gondwana.db`.
For deployment put HTTPS reverse proxy in front of port 8000, keep `/data` persistent,
use one instance, and back up the database. Do not expose the SQLite file or environment.
`GET /health` checks process availability. `/docs` describes request/response endpoints.
Rate-limit login, checkout and upload-ticket requests at the reverse proxy.

Docker option:

```bash
docker build -t gondwana-api backend
docker volume create gondwana-data
docker run --env-file backend/.env -v gondwana-data:/data -p 127.0.0.1:8000:8000 gondwana-api
```

## 2. Google login and main Admin

- Existing web OAuth client ID is retained in Android `res/values/strings.xml`.
- Put the SAME web client ID into server `GOOGLE_CLIENT_ID`.
- Set `ADMIN_EMAIL` to the exact Google email of the main Admin **before first login**.
- Configure Android OAuth client with package `com.gondwana.prime` and SHA-1 of your signing certificate.
- Debug, local release, and Play App Signing certificates may need separate Android OAuth clients.
- Use `./gradlew signingReport` to inspect fingerprints. GitHub temporary debug signing differs between fresh runners.
- Main Admin logs in, opens Account → Admin Panel. Other team members login once, then Admin assigns roles by email.
- Keep a stable signing key for future installed-app updates. Never commit it.

## 3. Private video storage

Use a **private** Cloudflare R2/S3-compatible bucket. Set `S3_ENDPOINT`, `S3_BUCKET`,
`S3_ACCESS_KEY`, `S3_SECRET_KEY` on the backend only. Restrict the storage credentials to this bucket.
Android never gets those credentials; it receives short-lived upload/playback URLs.

Admin flow: Account → Admin Panel → Videos → New video → select MP4 → wait for completion
→ enter title/prices/episode metadata → Save video. Use Android-playable H.264/AAC MP4 files.
Successful PUT alone does not publish a video; the server checks object size/type first.
Configure cleanup/lifecycle rules for orphaned uploads that never become catalog entries.

## 4. Payment setup (direct-distribution app)

Start with Razorpay test keys; do not test with real payments first.

Server environment:

- `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`: payment-link API credentials.
- `RAZORPAY_WEBHOOK_SECRET`: the webhook secret, separate from API key secret.
- `PAYMENTS_ENABLED=true` only after configuration and merchant validation.
- Webhook endpoint: `https://YOUR_BACKEND/api/native/payments/webhook`.
- Subscribe to `payment_link.paid` and `refund.processed`.
- Payment methods including UPI depend on the merchant account's enabled methods.

App opens provider HTTPS checkout. Returning to the app does not mark an order paid.
Refresh Account after payment; only signed, amount-matching server events grant access.
Duplicate delivery does not create duplicate access. Pending checkout links are reused briefly.
Refunds (including partial refunds) revoke the associated order's access; handle partial-refund
business policy manually. Provider webhook retries are required for out-of-order events.

Default example prices: monthly ₹99, yearly ₹999. Change `MONTHLY_PAISE` / `YEARLY_PAISE`
before launch. Rent/Buy prices are entered per video in Admin. All database amounts are paise.
Rent = 48 hours from confirmed payment; membership = 30 or 365 days, added to current expiry.
Buy grants a long-term entitlement (100-year technical expiry); it is not a downloadable copy.

**Automatic recurring debits and bank payouts are not enabled.** Creator reports track gross
Rent/Buy allocation, not net payable settlement. Subscription pooling needs an agreed rule.

For Play Store use `play` flavor, which hides external payment links. Play Billing or enrolled
alternative-billing integration and release-policy review are separate work before in-app sales.

## 5. Android build

Open the root folder in Android Studio, use JDK 17, install Android SDK 35.
The project includes Gradle 8.10.2 Wrapper. In your local Gradle properties add:

```properties
API_BASE_URL=https://YOUR_BACKEND
```

This must be the origin hosting the new `/api/native/...` routes, not the old demo website.
The empty default intentionally displays setup-pending errors instead of calling an incompatible server.

```bash
./gradlew assembleDirectDebug -PAPI_BASE_URL=https://YOUR_BACKEND
./gradlew assemblePlayDebug -PAPI_BASE_URL=https://YOUR_BACKEND
```

Windows: use `gradlew.bat`.
APK paths:

- `app/build/outputs/apk/direct/debug/app-direct-debug.apk`
- `app/build/outputs/apk/play/debug/app-play-debug.apk`

Alternative: put the contents of this root into GitHub, Actions → Build and test Gondwana Prime
→ Run workflow → enter API URL → download APK artifact.
These are debug APKs. Play release needs a signed release AAB, an appropriate target SDK,
privacy/data-safety declarations, account lifecycle handling and store review.

## 6. Events, votes, reports

Admin/Event Manager creates an event with any manual name/type. Turning Active ON makes it
the only active event. Save the event before adding candidates. For a performance link, use
“वीडियो चुनें” and select the uploaded video by title. Existing candidates can be edited; deletion is
blocked after votes exist. Public viewers see a vote button only while voting is ON.

Account → Devices removes other device sessions. Defaults: 3 registered devices, 1 concurrent
screen. A fresh login blocked by device limit requires logging out/removing a device from an
already signed-in device. Sessions expire after 7 days, then Google login is required again.

Admin → Reports shows distinct viewers, starts, watched seconds, last reported positions,
private vote totals and gross revenue allocations. Creator → Revenue shows only that creator's sales.
Reports count app-reported playback and are not fraud-proof royalty accounting.

## 7. Required end-to-end acceptance

Before public launch, verify on a real Android phone:

1. Google sign-in with correct SHA-1; invalid/expired login; logout and remote device removal.
2. MP4 upload, metadata edit, playback, replacing the selected video, home/background transitions.
3. Network disconnect/reconnect; retry; persistent progress across restart; My List add/remove.
4. Closed voting, valid vote, duplicate vote, single active event, uploader/event-manager restrictions.
5. Razorpay test success/failure/pending, duplicate webhook, refund, expired rental, membership renewal.
6. Storage access denial without a signed URL and correct permissions for provider secrets.
7. Signed release build, persistence/backups, recovery, rate limiting, privacy controls and load testing.

## Official integration references

- Google token validation: https://developers.google.com/identity/sign-in/android/backend-auth
- Credential Manager: https://developer.android.com/identity/sign-in/credential-manager-siwg-implementation
- Media3 PlayerView: https://developer.android.com/media/media3/ui/playerview
- Razorpay webhook validation: https://razorpay.com/docs/webhooks/validate-test/
- Razorpay Payment Links events: https://razorpay.com/docs/webhooks/payment-links/
- Play payments: https://support.google.com/googleplay/android-developer/answer/10281818
