# Gondwana Prime — Cloudflare R2 कम खर्च वाला Streaming Setup

## क्या बदला है
- FastAPI में R2 S3 client को cache किया गया है, ताकि हर playback और upload API call पर नया client न बने। यह **R2 Class A/B request की संख्या नहीं बदलता**; सिर्फ backend overhead कम करता है।
- `PLAYBACK_URL_TTL_SECONDS` नाम का configurable environment variable जोड़ा है। Default 3600 seconds है; allowed range 300–14400 seconds। यह signed URL की अवधि नियंत्रित करता है, **video delivery cost नहीं**। लंबी movies के लिए refreshable playback architecture आने तक 14400 seconds की जरूरत पड़ सकती है।
- Existing admin upload में direct presigned PUT, completion के समय HEAD verification और database-backed catalog सुरक्षित रखे गए हैं। यह current implementation में multipart upload नहीं है; बहुत बड़ी files के लिए multipart/resumable upload अलग development task है।
- Native Media3 ExoPlayer का मौजूदा MP4 playback बना हुआ है। HLS encoding, DRM और cache proxy अभी implement **नहीं** हुए हैं।

## R2 Standard Storage operations
- Class A: PUT, multipart upload parts, LIST आदि; पहले 10 लाख monthly free; उसके बाद $4.50 / 10 लाख।
- Class B: GET, HEAD आदि; पहले 1 करोड़ monthly free; उसके बाद $0.36 / 10 लाख।
- DELETE की billing अलग श्रेणी में free हो सकती है। Official pricing: https://developers.cloudflare.com/r2/pricing/
- R2 Standard Storage: पहले 10 GB-month free, उसके बाद $0.015/GB-month। Direct R2 egress $0; इसका अर्थ managed OTT streaming मुफ्त होना नहीं है।

## Recommended pilot steps
1. R2 में **private** bucket बनाएं; public access बंद रखें। R2 credentials सिर्फ backend environment में रखें।
2. Render पर `S3_ENDPOINT`, `S3_BUCKET`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `GOOGLE_CLIENT_ID`, `ADMIN_EMAIL` configure करें।
3. 1–3 मिनट का H.264/AAC MP4 upload करें। Current direct PUT upload की provider file-size limitations verify करें।
4. Admin upload/complete और दूसरे viewer का playback test करें। Android APK में R2 secrets कभी न डालें।
5. Cloudflare Dashboard में Storage, Class A, Class B usage और Render logs monitor करें। Cost alerts/limits configure करें जहाँ provider support करता हो।
6. Production के लिए HLS transcoding, signed manifest/segment delivery, CDN caching, rate limits, URL refresh, retries, secure content rights और concurrency load testing अलग से करें।

## Real-world limitations
- Backend uses SQLite and should have a persistent disk + backups.
- Shorter presigned URLs may expire during playback or after seeking. Verify 2-hour movies on real phones before launch.
- The native `Data Saver` only limits bitrate when multiple tracks exist; it does not transcode a single MP4.
- No guarantee of 10,000 viewers at ₹5,000/month without actual load testing and bills.
- Google Play and backend deployment are NOT performed by this ZIP.

## Build / tests
From `native-android`: `./gradlew assembleDirectDebug` (requires JDK17, Android SDK35 and dependencies). Backend: `cd backend && python -m pytest -q` after installing requirements and pytest.
