# Gondwana Prime — GitHub-ready additions

This ZIP contains **new files to merge** into the existing `gondwana-ott` repository. Do not replace or delete existing web app files.

## Contents
- `native-android/`: original Android + FastAPI project, excluding local Kotlin caches
- `.github/workflows/build-native-android.yml`: workflow with corrected nested paths
- `render.yaml`: Render blueprint with corrected backend root directory

## Steps
1. Back up or branch the existing repository. Merge these files into the repository root, preserving the existing web app.
2. Check GitHub Actions and run **Build and test Gondwana Prime**. The first build can use an empty API URL but will not connect to a live backend.
3. Create a Render Blueprint using root `render.yaml`. Review charges and set `ADMIN_EMAIL`, `S3_ENDPOINT`, `S3_BUCKET`, `S3_ACCESS_KEY`, and `S3_SECRET_KEY` privately. Never commit secrets.
4. Create a private Cloudflare R2 bucket and credentials before testing upload.
5. After backend health and Google OAuth configuration work, set GitHub Actions variable `API_BASE_URL` to the live HTTPS origin and rerun workflow.
6. Download the `gondwana-prime-debug-apks` artifact. Verify install and Google OAuth SHA-1 for the APK signing certificate.

## Cautions
- This package has **not** been pushed to GitHub, compiled, deployed, or tested on a device in this session.
- The Android package remains `com.gondwana.prime`.
- The workflow produces **debug APKs**, not a signed release AAB.
- Render service plan availability and Google OAuth configuration need verification in your own accounts.
- No existing web app files are included.
