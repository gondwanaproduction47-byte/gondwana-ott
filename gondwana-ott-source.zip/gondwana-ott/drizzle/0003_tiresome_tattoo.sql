ALTER TABLE `performances` ADD `poster_key` text;--> statement-breakpoint
ALTER TABLE `performances` ADD `thumbnail_key` text;